<?php
// Database configuration
$servername = "localhost"; // Replace with your server name
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "eventpro"; // Replace with your database name

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name =($_POST['name']);
    $email =($_POST['email']);
    $message =($_POST['message']);
    

    // SQL query to insert form data into the database
    $sql = "INSERT INTO contacts (name, email, message) VALUES ('$name', '$email', '$message')";

    if ($conn->query($sql) === TRUE) {
        //Redirect to "message-sent.html" page
        header("Location: message-sent.html");
        exit();
    } else {
        echo "Error: " .$conn->error;
    }
}

// Close the connection
$conn->close();
?>
