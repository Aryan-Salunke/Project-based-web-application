<?php
// Database connection
$servername = "localhost";
$username = "root"; // Default username for XAMPP/WAMP
$password = "";     // Default password for XAMPP/WAMP
$dbname = "location_data"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $state = $_POST['state'];
    $city = $_POST['city'];
    $pincode = $_POST['pincode'];
    $landmark = $_POST['landmark'];
    $street = $_POST['street'];

    // Insert data into the database
    $sql = "INSERT INTO locations (state, city, pincode, landmark, street) VALUES ('$state', '$city', '$pincode', '$landmark', '$street')";

    if ($conn->query($sql) === TRUE) {
        echo "Location details saved successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the connection
    $conn->close();
}
?>
