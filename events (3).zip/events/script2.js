// Event Buttons and Details
const buttons = document.querySelectorAll("button");
const imageGallery = document.getElementById("image-gallery");
const eventList = document.getElementById("event-list");
const marriageEvents = [
    {
        name: "Wedding Ceremony",
        description: "Elevate your wedding ceremony with our exquisite catering services.",
        image: "https://img.freepik.com/free-photo/sparkling-glassware-stands-long-table-prepared-wedding-di_8353-688.jpg",
        cateringMenu: [
            { name: "Spring Rolls", cost: 60 },
            { name: "Garlic Bread", cost: 75 },
            { name: "Stuffed Mushrooms", cost: 80 },
            { name: "Grilled Chicken", cost: 180 },
            { name: "Vegetarian Lasagna", cost: 100 },
            {name: "Beef Steak", cost: 260 },
            {name: "Chocolate Cake", cost:150},
            {name:"Ice Cearm",cost:30},
            { name: "Wine", cost: 200 },
          { name: "Cocktails", cost: 150 },


        ],
    },
    
];

const outdoorEvents = [
    {
        name: "Birthday Party",
        description: "Let's make your special day unforgettable with a personalized outdoor celebration.",
        image: "https://img.freepik.com/premium-photo/backyard-bbq-party-with-colorful-decorations-food_1079150-289023.jpg",
        cateringMenu: [
            { name: "Starter - Mini Sandwiches", cost: 4 },
            { name: "Starter - Cheese Balls", cost: 5 },
            { name: "Main Course - BBQ Burgers", cost: 12 },
            { name: "Main Course - Veg Wraps", cost: 10 },
        ],
    },
];

const indoorEvents = [
    {
        name: "Conference",
        description: "Delicious food and seamless service for your conference.",
        image: "https://img.freepik.com/premium-photo/people-group-catering-buffet-food-indoor-restaurant_916191-56849.jpg",
        cateringMenu: [
            { name: "Starter - Sandwich Platter", cost: 8 },
            { name: "Starter - Fruit Salad", cost: 6 },
            { name: "Main Course - Grilled Fish", cost: 18 },
            { name: "Main Course - Pasta Alfredo", cost: 15 },
        ],
    },
];

buttons.forEach((button) => {
    button.addEventListener("click", () => {
        imageGallery.innerHTML = "";
        eventList.innerHTML = "";
        const eventType = button.id;
        let events;

        switch (eventType) {
            case "marriage":
                events = marriageEvents;
                break;
            case "outdoor":
                events = outdoorEvents;
                break;
            case "indoor":
                events = indoorEvents;
                break;
            default:
                events = [];
        }

        events.forEach((event) => {
            const imageContainer = document.createElement("div");

            const img = document.createElement("img");
            img.src = event.image;
            img.alt = event.name;

            const imgText = document.createElement("p");
            imgText.textContent = event.name;

            img.addEventListener("click", () => {
                eventList.innerHTML = "";
                const eventItem = document.createElement("div");
                eventItem.classList.add("event-item");

                const eventName = document.createElement("h3");
                eventName.textContent = event.name;

                const eventDescription = document.createElement("p");
                eventDescription.textContent = event.description;

                const cateringMenu = event.cateringMenu || [];
                const menuList = document.createElement("ul");
                cateringMenu.forEach((menuItem) => {
                    const menuItemElement = document.createElement("li");
                    menuItemElement.textContent = `${menuItem.name}: $${menuItem.cost}`;
                    menuList.appendChild(menuItemElement);
                });

                eventItem.appendChild(eventName);
                eventItem.appendChild(eventDescription);

                if (cateringMenu.length > 0) {
                    const menuHeading = document.createElement("h4");
                    menuHeading.textContent = "Catering Menu:";
                    eventItem.appendChild(menuHeading);
                    eventItem.appendChild(menuList);
                }

                eventList.appendChild(eventItem);
            });

            imageContainer.appendChild(img);
            imageContainer.appendChild(imgText);
            imageGallery.appendChild(imageContainer);

           // Quote Form Submission
document.getElementById('quote-form').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent default form submission

    const form = event.target;
    const formData = new FormData(form);

    fetch(form.action, {
        method: form.method,
        body: formData,
    })
        .then((response) => response.text())
        .then((responseText) => {
            if (responseText.trim() === 'success') {
                alert('Your request has been submitted successfully!');
                // Redirect to thank-you page if needed
                // window.location.href = 'message-sent.html';
            } else {
                alert('An error occurred: ' + responseText);
            }
        })
        .catch((error) => {
            console.error('Error:', error);
            alert('An error occurred. Please try again later.');
        });
});
        });
    });
});