<?php
// Database credentials
$servername = "localhost"; // Change if your database is hosted elsewhere
$username = "root";        // Your database username
$password = "";            // Your database password
$dbname = "program"; // Replace with your database name

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize the message input
    $message = trim($_POST['message']);
    
    if (!empty($message)) {
        // Create a connection to the database
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check the connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare the SQL query
        $stmt = $conn->prepare("INSERT INTO messages (message) VALUES (?)");
        $stmt->bind_param("s", $message);

        // Execute the query
        if ($stmt->execute()) {
            echo "Message saved successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    } else {
        echo "Please enter a message.";
    }
} else {
    echo "Invalid request method.";
}
?>
