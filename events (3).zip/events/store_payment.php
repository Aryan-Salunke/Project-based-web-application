<?php
// Database configuration
$host = 'localhost'; // Change to your database host
$username = 'root'; // Change to your database username
$password = ''; // Change to your database password
$database = 'payment'; // Change to your database name

// Create a connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Retrieve payment details from POST request
$payment_id = $_POST['payment_id'];
$amount = $_POST['amount'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$method = $_POST['method'];
$timestamp = $_POST['timestamp'];

// Validate input
if (!$payment_id || !$amount || !$email || !$mobile || !$method || !$timestamp) {
    die("All fields are required.");
}

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO payments (payment_id, amount, email, mobile, method, timestamp) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sdssss", $payment_id, $amount, $email, $mobile, $method, $timestamp);

// Execute the query
if ($stmt->execute()) {
    echo "Payment details stored successfully.";
} else {
    echo "Error: " . $stmt->error;
}

// Close connection
$stmt->close();
$conn->close();
?>
