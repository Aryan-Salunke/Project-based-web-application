<?php
// Database credentials
$servername = "localhost";
$username = "root"; // Default username for phpMyAdmin
$password = "";    // Default password for phpMyAdmin (empty string for localhost)
$dbname = "eventpro_db"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $message = $_POST['message'];

    // Validate the input
    if (!empty($message)) {
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO messages (content) VALUES (?)");
        $stmt->bind_param("s", $message);

        // Execute the statement
        if ($stmt->execute()) {
            echo "Message stored successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Message cannot be empty.";
    }
}

// Close the connection
$conn->close();
?>