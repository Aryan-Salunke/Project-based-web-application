<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "signup_data";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$email = $_POST['email'];
$entered_password = $_POST['password'];

// Verify the user
$sql = "SELECT * FROM signs WHERE email='$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $stored_password = $row['password'];
    //debugging
    if ($entered_password === $stored_password) {
        echo "Login successful! Welcome, " . $row['username'];
        echo "<a href='homepage.html'>Homepage</a>";    
    } else {
        echo "Invalid password. <a href='log.html'>Try again</a>";
    }
} else {
    echo "No account found with that email. <a href='index.html'>Sign up</a>";
}

$conn->close();
?>
