
const monthSelect = document.getElementById("month-select");
const yearSelect = document.getElementById("year-select");
const calendarBody = document.getElementById("calendar-body");
const selectedDateDisplay = document.getElementById("selected-date").querySelector("span");
const clearBtn = document.getElementById("clear-btn");
const cancelBtn = document.getElementById("cancel-btn");
const setBtn = document.getElementById("set-btn");

let selectedDate = null;

// Populate Month and Year Select
const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
];
const currentYear = new Date().getFullYear();

function populateDropdowns() {
    months.forEach((month, index) => {
        const option = document.createElement("option");
        option.value = index;
        option.textContent = month;
        monthSelect.appendChild(option);
    });

    for (let year = currentYear ; year <= currentYear + 20; year++) {
        const option = document.createElement("option");
        option.value = year;
        option.textContent = year;
        yearSelect.appendChild(option);
    }

    const now = new Date();
    monthSelect.value = now.getMonth();
    yearSelect.value = now.getFullYear();
    renderCalendar(now.getFullYear(), now.getMonth());
}

// Render Calendar
function renderCalendar(year, month) {
    calendarBody.innerHTML = ""; // Clear previous calendar

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    let row = document.createElement("tr");

    for (let i = 0; i < firstDay; i++) {
        row.appendChild(document.createElement("td"));
    }

    for (let day = 1; day <= daysInMonth; day++) {
        const cell = document.createElement("td");
        cell.textContent = day;

        if (
            selectedDate &&
            selectedDate.year === year &&
            selectedDate.month === month &&
            selectedDate.day === day
        ) {
            cell.classList.add("selected");
        }

        cell.addEventListener("click", () => {
            selectedDate = { year, month, day };
            selectedDateDisplay.textContent = `${months[month]} ${day}, ${year}`;
            renderCalendar(year, month);
        });

        row.appendChild(cell);

        if (row.children.length === 7) {
            calendarBody.appendChild(row);
            row = document.createElement("tr");
        }
    }

    while (row.children.length < 7) {
        row.appendChild(document.createElement("td"));
    }
    calendarBody.appendChild(row);
}

// Clear Button
clearBtn.addEventListener("click", () => {
    selectedDate = null;
    selectedDateDisplay.textContent = "No date selected";
    renderCalendar(parseInt(yearSelect.value), parseInt(monthSelect.value));
});

// Cancel Button
cancelBtn.addEventListener("click", () => {
    alert("Date selection canceled!");
});

// Set Button
setBtn.addEventListener("click", () => {
    if (selectedDate) {
        alert(`Selected Date: ${months[selectedDate.month]} ${selectedDate.day}, ${selectedDate.year}`);
    } else {
        alert("No date selected!");
    }
});

// Dropdown Changes
monthSelect.addEventListener("change", () => {
    renderCalendar(parseInt(yearSelect.value), parseInt(monthSelect.value));
});
yearSelect.addEventListener("change", () => {
    renderCalendar(parseInt(yearSelect.value), parseInt(monthSelect.value));
});

// Initialize
populateDropdowns();


// Reservation Modal
const reservationModal = document.getElementById("reservation-modal");
const closeModalBtn = reservationModal.querySelector(".close");
const reservationForm = document.getElementById("reservation-form");

// Show Modal
setBtn.addEventListener("click", () => {
    if (selectedDate) {
        reservationModal.classList.remove("hidden");
        reservationModal.style.display = "flex";  
    } else {
        alert("No date selected!");
    }
});

// Close Modal
closeModalBtn.addEventListener("click", () => {
    reservationModal.classList.add("hidden");
});

// Confirm Reservation
reservationForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const name = document.getElementById("customer-name").value.trim();
    const phone = document.getElementById("customer-phone").value.trim();
    const email = document.getElementById("customer-email").value.trim();
    const description = document.getElementById("event-description").value.trim();

    if (name && phone && email && description) {
        alert(`Reservation Confirmed!
Date: ${months[selectedDate.month]} ${selectedDate.day}, ${selectedDate.year}
Name: ${name}
Phone: ${phone}
Email: ${email}
Description: ${description}`);

        // Reset form and close modal
        reservationForm.reset();
        reservationModal.classList.add("hidden");
    } else {
        alert("All fields are required!");
    }
});

// Close Modal (Enhanced)
closeModalBtn.addEventListener("click", () => {
    reservationModal.classList.add("hidden");
    reservationModal.style.display = "none"; // Ensures it hides from the viewport
});

// Pay Now Button Functionality
const payNowBtn = document.getElementById("pay-now-btn");

payNowBtn.addEventListener("click", () => {
    if (selectedDate) {
        alert(`Proceeding to payment for the reservation on ${months[selectedDate.month]} ${selectedDate.day}, ${selectedDate.year}.`);
        
        // Retrieve the payment page URL from the data attribute
        const paymentPageUrl = payNowBtn.getAttribute('data-href');

        // Redirect to the payment page
        if (paymentPageUrl) {
            window.location.href = paymentPageUrl;
        } else {
            console.error('Payment page URL is not defined.');
        }
    } else {
        alert("No date selected! Please confirm a reservation date first.");
    }
});