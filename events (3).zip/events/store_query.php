<?php
// Database configuration
$servername = "localhost";
$username = "root"; // Default username for phpMyAdmin
$password = ""; // Default password for phpMyAdmin
$dbname = "event_management"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is a 'query' submission or 'rating' submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Check for query submission (from 'Contact Us' form)
    if (isset($_POST['query'])) {
        $query = $_POST['query'];

        // Prepare and bind SQL statement to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO feedback (query_text) VALUES (?)");
        $stmt->bind_param("s", $query);

        // Execute the statement
        if ($stmt->execute()) {
            echo "Message sent successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }

    // Check for rating submission (from 'Rate Our Service' form)
    if (isset($_POST['rating'])) {
        $rating = $_POST['rating'];
        $comment = $_POST['comment'];

        // Validate rating input
        if (empty($rating) || !is_numeric($rating) || $rating < 1 || $rating > 5) {
            echo "Invalid rating. Please select a rating between 1 and 5.";
            exit;
        }

        // Validate comment (optional but ensure it is not empty)
        if (empty($comment)) {
            echo "Please provide a comment.";
            exit;
        }

        // Prepare and bind SQL statement to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO feedback (rating, comment) VALUES (?, ?)");
        $stmt->bind_param("is", $rating, $comment);

        // Execute the statement
        if ($stmt->execute()) {
            echo "Thank you for your feedback!";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
    $conn->close();
} else {
    echo "Invalid request.";
}
?>
